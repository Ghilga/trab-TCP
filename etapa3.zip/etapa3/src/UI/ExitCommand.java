package UI;

public class ExitCommand extends UICommand {
	public void execute() {
		System.out.println("\n\n\n\n\n\n\n\n\n");
	}
	
	@Override
	public String toString() {
		return "Sair";
	}
}
