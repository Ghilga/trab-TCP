package test;

import org.junit.*;

import domain.Database;

import static org.junit.Assert.*;

public class EvaluationGroupTest {

	@Before
	public void setUp() throws Exception {
		Database.initialize();
	}
	
}
